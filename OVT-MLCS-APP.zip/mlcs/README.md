Run the following command under a linux shell,DO NOT USE ROOT user.
### Prerequisites

    1. Java 21 Runtime

### install

    unzip mlcs.zip
    cd mlcs
    bin/init.sh

### run webapp

    bin/start.sh mlcs

### stop webapp

    bin/stop.sh mlcs

### Configuration

  Edit config file(conf/server.xml),change memory and port.

    <Farm name="mlcs" engine="tomcat11" maxHeapSize="500m">
      <ServerOptions>-Duser.timezone=Asia/Shanghai</ServerOptions>
      <Http acceptCount="100" maxThreads="200" />
      <Server name="server1"  http="6980"  />
    </Farm>

Examples.
1. change "500m" to "2G" or "4G"
2. change  http="6980" to http="8080"