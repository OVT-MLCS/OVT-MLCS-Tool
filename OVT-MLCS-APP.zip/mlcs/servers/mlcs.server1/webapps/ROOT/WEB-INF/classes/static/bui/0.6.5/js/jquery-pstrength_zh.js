digitalspaghetti.password.defaults.minCharText='至少%d个字符';
digitalspaghetti.password.defaults.verdicts=['弱', '正    常', '中   度', '强!', '很   强!'];
